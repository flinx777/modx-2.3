<?php
/**
 * English Preload Lexicon Topic for Revolution setup
 *
 * @package setup
 * @subpackage lexicon
 */
$_lang['preload_err_cache'] = '[[+path]]cache ディレクトリーのパーミッションを書き込み可能にしてください。';
$_lang['preload_err_core_path'] = 'setup/includes/config.core.php を開き、MODX_CORE_PATHの値を修正してください。このパラメータはcoreディレクトリの場所を指している必要があります。';
$_lang['preload_err_pdo'] = 'PDO拡張モジュールを認識できません。';