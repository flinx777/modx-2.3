<?php
/**
 * Specific upgrades for Revolution 2.2.0-rc2
 *
 * @var modX $modx
 *
 * @package setup
 * @subpackage upgrades
 */
/* TV renders upgrades */
include dirname(dirname(__FILE__)).'/common/2.2-tv-renders.php';