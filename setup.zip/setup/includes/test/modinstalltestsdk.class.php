<?php
/**
 * Handles all SDK build-specific checks
 *
 * @package setup
 * @subpackage tests
 */
class modInstallTestSdk extends modInstallTest {

    public function run($mode = modInstall::MODE_NEW) {
        return parent::run($mode);
    }

}
